# Security Audit Report: Botium Toys

## 1. Overview

This report presents the results of an internal security audit conducted for Botium Toys, a small toy business with both physical and online operations. As the business expands its digital presence and processes online payments, its exposure to cyber threats, compliance obligations, and operational risk increases.

The purpose of this audit is to evaluate the current state of the organization's security controls, identify major gaps, and recommend actions to strengthen its security posture.

## 2. Audit Scope

The audit focuses on the IT environment supporting Botium Toys' operations, especially assets managed by the IT department and risks linked to online sales, payment processing, and international business operations.

Assets considered include:

- Internal IT systems
- Online storefront infrastructure
- Customer information
- Payment data
- Employee access to systems and data
- Business operations dependent on IT availability

## 3. Audit Goals

The goals of the audit are to:

- Identify existing security controls
- Determine which critical controls are missing
- Review compliance-related best practices
- Assess risks to customers, employees, assets, and operations
- Recommend security improvements based on findings

## 4. Method

The audit was performed by reviewing the scenario materials, considering the stated risks, applying control categories, and completing a controls and compliance checklist.

The review used a simple yes/no assessment model to identify whether major controls and compliance practices were currently implemented.

## 5. Controls Assessment

The following controls were assessed:

| Control | Status |
|---|---|
| Least privilege | No |
| Disaster recovery plans | No |
| Password policies | No |
| Separation of duties | No |
| Firewall | Yes |
| Intrusion detection system | No |
| Backups | No |
| Antivirus software | Yes |
| Legacy system monitoring | Yes |
| Encryption | No |
| Password management system | No |

## 6. Compliance Assessment

### PCI DSS

| Requirement Area | Status |
|---|---|
| Access to credit card data restricted | No |
| Secure processing and storage of card data | No |
| Encryption implemented | No |
| Strong password policies | No |

### GDPR

| Requirement Area | Status |
|---|---|
| EU customer data secured | No |
| Breach notification within 72 hours | No |
| Data classification and inventory | No |

### SOC-related Best Practices

| Requirement Area | Status |
|---|---|
| User access policies | No |
| Data confidentiality | No |
| Data integrity | No |
| Data availability | No |

## 7. Risk Analysis

The audit findings suggest that Botium Toys faces elevated risk in several areas:

### Customer Risk

Weak protection of payment and customer data can expose the business to fraud, data breaches, reputational damage, and regulatory penalties.

### Operational Risk

The lack of backups and disaster recovery planning increases the chance of severe downtime, data loss, and disruption to sales and warehouse operations.

### Access Control Risk

Without least privilege, separation of duties, and clear password policies, the company is more vulnerable to insider threats, account compromise, and unauthorized access.

### Compliance Risk

Because Botium Toys accepts online payments and serves customers in the European Union, gaps related to PCI DSS and GDPR may lead to fines, legal exposure, and loss of customer trust.

## 8. Key Findings

The organization has only limited foundational controls in place. While the presence of a firewall and antivirus software provides some baseline protection, the overall security posture remains weak because many essential preventive, detective, and recovery controls are absent.

The most serious concerns are:

- No formal disaster recovery capability
- No backup process
- No encryption for sensitive data
- Weak access governance
- Poor compliance readiness
- Limited visibility into attacks due to lack of intrusion detection

## 9. Recommendations

1. Implement least privilege access controls across systems and roles.
2. Establish and enforce strong password policies.
3. Deploy a password management solution.
4. Implement encrypted storage and transmission of sensitive data.
5. Create and test backup and disaster recovery procedures.
6. Introduce separation of duties for sensitive processes.
7. Deploy an intrusion detection or monitoring solution.
8. Develop data classification and retention procedures.
9. Improve PCI DSS and GDPR compliance readiness.
10. Create a breach response process, including 72-hour notification procedures where required.

## 10. Conclusion

Botium Toys needs significant security improvements to reduce risk and support safe business growth. The audit shows that the company is not yet well positioned to protect sensitive data, maintain availability during incidents, or satisfy important compliance expectations. By implementing the recommended controls, Botium Toys can materially improve resilience, compliance readiness, and trust.
