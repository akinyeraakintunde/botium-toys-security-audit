# Botium Toys Security Audit

A portfolio-ready cybersecurity project based on an internal security audit scenario for **Botium Toys**. This project demonstrates how to review audit scope, identify missing controls, evaluate compliance gaps, and provide practical recommendations.

## Project Summary

Botium Toys is a small business with growing online operations. The company needs an internal IT audit to better understand risks to its customers, employees, systems, and business operations. The audit focuses on:

- Existing security controls
- Compliance requirements
- Operational risk
- Gaps in security posture
- Recommended improvements

## Objectives

- Review the audit scope, goals, and risk assessment
- Assess current security controls
- Map gaps against compliance expectations
- Recommend improvements to reduce business risk
- Present findings in a professional portfolio format

## Files in this Repository

- `docs/security_audit_report.md` — Full narrative audit report
- `docs/recommendations.md` — Priority recommendations for leadership
- `data/controls_and_compliance_checklist.csv` — Completed checklist in table format
- `data/risk_summary.csv` — Summary of key risks and impact areas

## Key Findings

Botium Toys has some basic protections in place, such as:

- Firewall
- Antivirus software
- Legacy system monitoring

However, several important controls appear to be missing or insufficient, including:

- Least privilege
- Disaster recovery planning
- Password policies
- Separation of duties
- Intrusion detection system
- Backups
- Encryption
- Password management system

Compliance readiness is also weak in major areas relevant to:

- PCI DSS
- GDPR
- SOC-related good practices

## Skills Demonstrated

- Security auditing
- Risk identification
- Control assessment
- Compliance gap analysis
- Security documentation
- Technical writing
- Cybersecurity portfolio development

## How to Present This Project on GitHub

Use this repository to show employers that you can:

1. Read a business scenario and define audit scope
2. Assess internal controls
3. Identify compliance risks
4. Write professional security recommendations
5. Translate technical findings into business language

## Sample Resume Bullet

Conducted a security audit for a fictional retail organization, assessing internal controls, compliance gaps, and operational risk using a structured controls and compliance checklist; documented findings and recommendations in a portfolio-ready GitHub project.

## Author

Prepared by Ibrahim Akinyera as part of a cybersecurity portfolio project.
